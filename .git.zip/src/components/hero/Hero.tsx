import { profile } from '@/content';
import { useLanguage } from '@/i18n';
import { useTypewriterLoop } from '@/hooks/useTypewriterLoop';
import { TypedText } from '@/components/editor/TypedText';
import { HeroStats } from './HeroStats';
import { PhotoCard } from './PhotoCard';
import { PortfolioTitle } from './PortfolioTitle';
import { SkillInspector } from './SkillInspector';
import './Hero.css';

interface HeroProps {
  /** Verdadeiro quando a abertura termina: dispara as animações do topo. */
  play: boolean;
  reducedMotion: boolean;
}

export function Hero({ play, reducedMotion }: HeroProps) {
  const { t, pick } = useLanguage();
  const role = useTypewriterLoop(pick(profile.roles), play && !reducedMotion);

  return (
    <header className="hero" id="topo">
      <div className="container">
        <PortfolioTitle play={play && !reducedMotion} />

        <div className="hero__grid">
          <div className="hero__main">
            <div className="hero__hello" data-edit="hello">
              {t.hello}
            </div>
            <h1 className="hero__name" data-edit="name" data-layer="h1.nome" data-offset="170,-46,-7,1">
              {profile.firstName}.
            </h1>
            <div className="hero__fullname mono">
              {profile.fullName} · {profile.location}
            </div>

            <div className="hero__role mono">
              <i />
              <span>{role}</span>
              <span className="hero__role-caret" />
            </div>

            <TypedText className="hero__lead" data-edit="lead" typingId="lead" text={pick(profile.lead)} />

            <div className="hero__ctas">
              <a className="button button--primary" href="#projetos">
                {t.ctaProjects} →
              </a>
              <a className="button" href="#contato">
                {t.ctaContact}
              </a>
            </div>

            <HeroStats play={play} />
          </div>

          <PhotoCard reducedMotion={reducedMotion} />
          <SkillInspector play={play} />
        </div>
      </div>
    </header>
  );
}
