import { useEffect, useRef } from 'react';
import './PortfolioTitle.css';

/** "PORTFÓLIO" gigante só com contorno, que se desenha quando `play` vira verdadeiro. */
export function PortfolioTitle({ play }: { play: boolean }) {
  const strokeRef = useRef<SVGTextElement>(null);
  const wipeRef = useRef<SVGRectElement>(null);
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    const text = strokeRef.current;
    const wipe = wipeRef.current;
    if (!play || !text || !wipe) return;

    const length = 5200;
    text.style.strokeDasharray = String(length);
    text.style.strokeDashoffset = String(length);
    text.getBoundingClientRect(); // força o navegador a aplicar o estado inicial
    text.style.transition = 'stroke-dashoffset 2.2s cubic-bezier(.6,0,.2,1)';
    text.style.strokeDashoffset = '0';

    let frame = 0;
    const start = performance.now();
    const fill = (now: number) => {
      const p = Math.min(1, (now - start - 900) / 1400);
      wipe.setAttribute('width', String(Math.max(0, p) * 1240));
      if (p < 1) frame = requestAnimationFrame(fill);
    };
    frame = requestAnimationFrame(fill);
    return () => cancelAnimationFrame(frame);
  }, [play]);

  // leve paralaxe com a rolagem
  useEffect(() => {
    const onScroll = () => {
      if (svgRef.current && window.scrollY < 900) {
        svgRef.current.style.transform = `translateY(${window.scrollY * 0.25}px)`;
      }
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <svg ref={svgRef} className="portfolio-title" viewBox="0 0 1240 270" role="img" aria-label="Portfólio">
      <defs>
        <clipPath id="portfolio-wipe">
          <rect ref={wipeRef} x="0" y="0" width={play ? 0 : 1240} height="270" />
        </clipPath>
      </defs>
      <text ref={strokeRef} x="620" y="245" textAnchor="middle" textLength="1230" lengthAdjust="spacingAndGlyphs">
        PORTFÓLIO
      </text>
      <text
        className="portfolio-title__fill"
        x="620"
        y="245"
        textAnchor="middle"
        textLength="1230"
        lengthAdjust="spacingAndGlyphs"
        clipPath="url(#portfolio-wipe)"
      >
        PORTFÓLIO
      </text>
    </svg>
  );
}
