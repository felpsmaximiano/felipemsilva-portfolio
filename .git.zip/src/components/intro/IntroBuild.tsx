import { useEffect, useRef, useState } from 'react';
import { useLanguage } from '@/i18n';
import { SelectionBox } from '@/components/ui/SelectionBox';
import './IntroBuild.css';

interface Box {
  label: string;
  x: number;
  y: number;
  w: number;
  h: number;
}

/** Caixas que "voam" até as posições das partes do site (frações da tela). */
const LAYOUT: Box[] = [
  { label: 'nav', x: 0, y: 0, w: 1, h: 0.07 },
  { label: 'hero.titulo', x: 0.06, y: 0.14, w: 0.88, h: 0.24 },
  { label: 'h1.nome', x: 0.06, y: 0.44, w: 0.3, h: 0.12 },
  { label: 'felipe.foto', x: 0.5, y: 0.42, w: 0.2, h: 0.42 },
  { label: 'inspetor', x: 0.76, y: 0.42, w: 0.18, h: 0.3 },
  { label: 'cta.primario', x: 0.06, y: 0.66, w: 0.16, h: 0.07 },
];

const DURATION_MS = 2100;

/** Abertura: a página aparece como uma tela de editor sendo montada, com log de build. */
export function IntroBuild({ onDone }: { onDone: () => void }) {
  const { t } = useLanguage();
  const [step, setStep] = useState(0);
  const [hidden, setHidden] = useState(false);
  const doneRef = useRef(false);
  // posições iniciais aleatórias, sorteadas uma vez
  const [starts] = useState(() => LAYOUT.map(() => ({ x: Math.random() * 0.8, y: Math.random() * 0.8 })));

  const finish = () => {
    if (doneRef.current) return;
    doneRef.current = true;
    setHidden(true);
    onDone();
  };

  useEffect(() => {
    const timers = [
      ...LAYOUT.map((_, i) => window.setTimeout(() => setStep((s) => Math.max(s, i + 1)), 120 + i * 110)),
      window.setTimeout(finish, DURATION_MS),
    ];
    return () => timers.forEach(window.clearTimeout);
    // eslint-disable-next-line react-hooks/exhaustive-deps -- roda uma única vez na montagem
  }, []);

  const logLines = t.buildLog.slice(0, Math.min(t.buildLog.length, Math.ceil(step / 1.5)));

  return (
    <div className={`intro${hidden ? ' is-done' : ''}`} aria-hidden="true" onClick={finish}>
      {LAYOUT.map((box, i) => {
        const placed = step > i;
        const pos = placed ? box : { ...starts[i], w: 0.03, h: 0.04 };
        return (
          <div
            key={box.label}
            className={`intro__box${placed ? ' is-placed' : ''}`}
            style={{
              left: `${pos.x * 100}vw`,
              top: `${pos.y * 100}vh`,
              width: `${pos.w * 100}vw`,
              height: `${pos.h * 100}vh`,
            }}
          >
            <SelectionBox label={box.label} className="intro__selection" />
          </div>
        );
      })}
      <div className="intro__log">
        {logLines.map((line, i) => (
          <div key={line} className={i === t.buildLog.length - 1 ? 'is-ok' : undefined}>
            {line}
          </div>
        ))}
      </div>
      <button type="button" className="intro__skip" onClick={finish}>
        {t.skip}
      </button>
    </div>
  );
}
