import { useEffect, useState } from 'react';

/** Digita e apaga cada palavra da lista em loop (ex.: os cargos no topo). */
export function useTypewriterLoop(words: readonly string[], enabled: boolean) {
  const [text, setText] = useState(enabled ? '' : words.join(' · '));

  useEffect(() => {
    if (!enabled) {
      setText(words.join(' · '));
      return;
    }
    let index = 0;
    let chars = 0;
    let deleting = false;
    let timer = 0;

    const tick = () => {
      const word = words[index % words.length];
      if (!deleting) {
        chars += 1;
        if (chars >= word.length) {
          deleting = true;
          setText(word);
          timer = window.setTimeout(tick, 1800);
          return;
        }
      } else {
        chars -= 1;
        if (chars <= 0) {
          deleting = false;
          index += 1;
        }
      }
      setText(word.slice(0, chars));
      timer = window.setTimeout(tick, deleting ? 28 : 55);
    };

    tick();
    return () => window.clearTimeout(timer);
  }, [words, enabled]);

  return text;
}
